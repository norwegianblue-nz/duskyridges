(function ($) {

  "use strict";
  
  Drupal.behaviors.customBehavior = {
    // perform jQuery as normal in here
  };
  
})(jQuery);
