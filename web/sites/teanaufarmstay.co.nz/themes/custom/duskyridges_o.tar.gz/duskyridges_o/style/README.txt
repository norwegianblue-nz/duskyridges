## 2016 Aug 5
## ==========
## 
## Omega 8.x.5.0-alpha7 installed.
## This version doesn't seem to compile SCCS.
## 
## Therefore, for this project we are working directly in css.
## Once the layout was created, I copied the layout.scss to this directory and copied
## in the omega_mixins and then compiled to css by hand (on Scud)
## 
## Further edits will be made directly in css.
## Any changes made to scss will not be reflected in the project.
## 
## A PEALING 20160805